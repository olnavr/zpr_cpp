#ifndef _TESTCLASS_H
#define _TESTCLASS_H
#include "Element.h"

class TestClass //TEST CLASS
{
public:
	TestClass();
	~TestClass();
	static SElement^ testGetSensor();
};
#endif

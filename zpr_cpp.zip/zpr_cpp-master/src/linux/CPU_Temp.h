/**
 * @file CPU_TEMP.h
 * @author Oleh Navrotskyi
 * @date 24.11.2017
 * @brief Plik zawierający deklarację klasy CPU_Temp, służącej do wykonania pomiaru temperatury
 *
 */

#ifndef CPU_TEMP_H
#define CPU_TEMP_H

#include "SystemUnit.h"

class CPU_Temp: public SystemUnit {
public:
    CPU_Temp(){name = "CPU_Temp";}
    std::string getUsage();
private:
    const std::string path = "/sys/class/hwmon/hwmon1/temp1_input";
};

#endif /* CPU_TEMP_H */


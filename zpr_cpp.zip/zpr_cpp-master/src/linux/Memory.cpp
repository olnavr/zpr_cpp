/**
 * @file Memory.cpp
 * @author Oleh Navrotskyi
 * @date 24.11.2017
 * @brief Plik zawierający implementację metod klasy Memory
 *
 */

#include "Memory.h"

/**
   Metoda służaca do odczytu zajętości pamięci RAM

   @param - None.
   @return - zwracany jest string, w postaci:
	MemTotal:        X kB
	MemFree:         XX kB
	MemAvailable:    Y kB
	Buffers:           YY kB
	Cached:          YY kB
 */

std::string Memory::getUsage(){
    const int N = 5;
    std::string temp;
    std::string usage;
    this->file.open(path);
    for(int i=0;i<N;++i){
        std::getline(file,temp);
        usage+=temp+"\n";
    }
    this->file.close();    
    return usage;
};

/**
 * @file SystemModel.cpp
 * @author Oleh Navrotskyi
 * @date 14.12.2017
 * @brief Plik zawierający implementację metod klasy SystemModel
 *
 */
#include "SystemModel.h"

/*
*
*	Dodanie nowego modułudo systemu
*
*/

void SystemModel::addUnit(SystemUnitPrt& un){
    this->systemUnits.emplace(un->name,un);
}

/*
*
*	Dodanie kontenera
*
*/
void SystemModel::addContener(ContainerPtr& c){
    this->container_ = c;
};

/*
*
*	Aktualizacja danych kontenera nowymi danymi z modułów
*
*/
void SystemModel::update(){
    std::string currentUsage;
    std::string firstt;
    for(auto elem: systemUnits){
        currentUsage = elem.second->getUsage();
	firstt = elem.first;
        container_->write(firstt,currentUsage);
   
    }
}


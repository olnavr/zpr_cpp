/**
 * @file SystemUnit.cpp
 * @author Oleh Navrotskyi
 * @date 1.12.2017
 * @brief Plik zawierający implementację metod klasy SystemUnit
 *
 */

#include "SystemUnit.h"
#include <iostream>

/*
*	Sygnalizyje że moduł konkretny nie implementuje swojej funkcji getUseage
*
*/
std::string SystemUnit::getUsage(void){
    std::string temp;
    temp = "Information is not provided";
    std::cout<<"Information is not provided"<<std::endl;
    return temp;
}

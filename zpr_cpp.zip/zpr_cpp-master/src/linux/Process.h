/**
 * @file Process.h
 * @author Oleh Navrotskyi
 * @date 30.11.2017
 * @brief Plik zawierający deklaracje klasy Process
 *
 */

#ifndef PROCESS_H
#define PROCESS_H

#include "SystemUnit.h"

struct  Process: public SystemUnit {
     public:
        Process(){name = "Process";};
        std::string getUsage(void);
    private:
        const std::string command = "ps -A o pid,cmd,%cpu "; 
};

#endif /* PROCESS_H */


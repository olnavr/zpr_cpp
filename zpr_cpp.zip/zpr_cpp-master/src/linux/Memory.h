/**
 * @file Memory.c
 * @author Oleh Navrotskyi
 * @date 24.11.2017
 * @brief Plik zawierający deklaracje klasy Memory
 *
 */

#ifndef MEMORY_H
#define MEMORY_H

#include "SystemUnit.h"

class Memory: public SystemUnit {
    public:
        Memory(){name = "RAM_usage";};
        std::string getUsage();
    private:
        std::string usage;
        const std::string path = "/proc/meminfo";
};

#endif /* MEMORY_H */


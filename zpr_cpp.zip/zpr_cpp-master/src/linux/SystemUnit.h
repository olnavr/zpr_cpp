/**
 * @file SystemUnit.h
 * @author Oleh Navrotskyi
 * @date 1.12.2017
 * @brief Plik zawierający deklarację klasy SystemUnit
 *
 */


#ifndef SYSTEMUNIT_H
#define SYSTEMUNIT_H

#include "Container.h"

#include <memory>
#include <iostream>
#include <fstream> 
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <array>

/**
 *	Klasa SystemUnit jest "absraktną" reprezentacją moduł systemu(np. CPU), służy do ujednolicenia interfejsu
 * 	różnych kłasy służcych do wydobywania tej lub innej informacji z systemu. zmiena name - słuzy do reprezentacji
 *	modułu w systemie, funkcja wirtualna getUsage - zwraca mierzone dane 
 *
 */

class SystemUnit {
public:
    friend class SystemModel;
    virtual std::string getUsage(void);
    std::string name;
protected:
    const std::string path;
    std::ifstream file;
};

typedef std::shared_ptr<SystemUnit> SystemUnitPrt;
typedef std::map<std::string,SystemUnitPrt> UnitMap;

#endif /* SYSTEMUNIT_H */


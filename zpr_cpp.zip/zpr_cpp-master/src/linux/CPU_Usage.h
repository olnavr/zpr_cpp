/**
 * @file CPU_Usage.h
 * @author Oleh Navrotskyi
 * @date 24.11.2017
 * @brief Plik zawierający deklarację klasy CPU_Temp, służącej do badania zajętości procesora
 *
 */

#ifndef CPU_H
#define CPU_H

#include "SystemUnit.h"
#include <array>

class CPU_Usage: public SystemUnit {
    public:
        CPU_Usage(){name = "CPU_Usage";}
        std::string getUsage();
    private:
        const std::string path = "/proc/stat";
	std::vector<std::array<float,4> > u_prev;
};

#endif /* CPU_H */


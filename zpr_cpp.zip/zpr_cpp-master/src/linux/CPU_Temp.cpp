/**
 * @file CPU_TEMP.c
 * @author Oleh Navrotskyi
 * @date 24.11.2017
 * @brief Plik zawierający implementację metod klasy CPU_Temp
 *
 */

#include "CPU_Temp.h"

/**
   Metoda służaca do odczytu temperatury procesora

   @param - None.
   @return - zwracany jest string, który reprezantuje temperaturę w Celsjuszach
 */

std::string CPU_Temp::getUsage(){
    float t;
    std::string usage;
    std::string temp;
    this->file.open(this->path);
    std::getline(file,temp);
    std::istringstream scan(temp);
    scan>>t;
    t = t/1000;
    usage = std::to_string(t);
    this->file.close();
    return usage;
}


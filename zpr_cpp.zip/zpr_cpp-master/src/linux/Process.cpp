/**
 * @file Memory.cpp
 * @author Oleh Navrotskyi
 * @date 1.12.2017
 * @brief Plik zawierający implementację metod klasy Process
 *
 */

#include "Process.h"
#include "Process.h"
/**
   Metoda służaca do odczytu zajętości zasobów procesora przez poszczególne procesy

   @param - None.
   @return - zwracany jest string, w tablicy o kolumnach PID, CMD, CPU, każdy wiersz reprezentuje proces
 */
std::string Process::getUsage(void){
	const int len = 20000;
	char buff[len];
	std::string str_buf;
	FILE *ptr = popen( command.c_str(), "r" );
	fread ( buff, 1,20000, ptr);
	str_buf.assign(buff,std::char_traits<char>::length(buff));
	fclose(ptr);
	return str_buf;
}

/**
 * @file OS.cpp
 * @author Oleh Navrotskyi
 * @date 13.12.2017
 * @brief Plik zawierający implementację metod klasy OS
 *
 */

#include "OS.h"

/**
   Metoda służaca do odczytu informacji o systemie operacyjnym

   @param - None.
   @return - zwracany jest string, zawierajacy informację o systemie operacyjnym
 */

std::string OS::getUsage(void){
    std::string usage;
    this->file.open(this->path);
    std::getline(file,usage);
    usage+="\n";
    this->file.close();
    return usage;
};

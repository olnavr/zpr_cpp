/**
 * @file SystemModel.h
 * @author Oleh Navrotskyi
 * @date 13.12.2017
 * @brief Plik zawierający deklarację klasy SystemModel
 *
 */

#ifndef SYSTEMCONTROL_H
#define SYSTEMCONTROL_H

#include "SystemUnit.h"
#include "Container.h"
#include <string>

/**
 *	Kłasa SystemModel służy do zarządania modulami systemu, zapisu danych z nich do kontenera. 
 *
 */

class SystemModel{

public:
    void addUnit(SystemUnitPrt&);
    void addContener(ContainerPtr&);
    void update(void);
private:
    UnitMap systemUnits;
    ContainerPtr container_;
    
};

#endif /* SYSTEMCONTROL_H */


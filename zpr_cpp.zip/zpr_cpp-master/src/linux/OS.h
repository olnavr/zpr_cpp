/**
 * @file OS.h
 * @author Oleh Navrotskyi
 * @date 24.11.2017
 * @brief Plik zawierający deklaracje klasy OS (informacja o  systemie operacyjnym)
 *
 */

#ifndef OS_H
#define OS_H

#include "SystemUnit.h"


class OS: public SystemUnit {
    public:
        OS(){name = "OS";};
        std::string getUsage(void);
    private:
        const std::string path = "/proc/version";
};

#endif /* OS_H */

